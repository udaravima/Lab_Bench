*PADS-LIBRARY-PART-TYPES-V9*

DAC80502DRXT SON50P250X250X80-10N I ANA 7 1 0 0 0
TIMESTAMP 2026.07.14.16.59.44
"Mouser Part Number" 595-DAC80502DRXT
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/DAC80502DRXT?qs=xZ%2FP%252Ba9zWqYW2HpXLkuTBA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" DAC80502DRXT
"Description" Digital to Analog Converters - DAC Dual-channel, 1-LSB INL, 16-bit, SPI voltage-output digital-to-analog converter (DAC) 10-WSON -40 to 125
"Datasheet Link" https://www.arrow.com/en/products/dac80502drxt/texas-instruments
"Geometry.Height" 0.8mm
GATE 1 10 0
DAC80502DRXT
1 0 U VDD
2 0 U VOUTA
3 0 U RSTSEL
4 0 U AGND
5 0 U SPI2C
10 0 U VREFIO
9 0 U VOUTB
8 0 U SDIN/SDA
7 0 U \SYNC\/A0
6 0 U SCLK/SCL

*END*
*REMARK* SamacSys ECAD Model
12179069/1193989/2.50/10/3/Integrated Circuit
